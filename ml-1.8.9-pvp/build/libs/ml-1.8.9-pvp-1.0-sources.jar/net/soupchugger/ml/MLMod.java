package net.soupchugger.ml;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGameOver;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ChatComponentText;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

@Mod(
        modid   = MLMod.MODID,
        name    = MLMod.NAME,
        version = MLMod.VERSION,
        clientSideOnly = true
)
public class MLMod {

    public static final String MODID   = "mlpvp";
    public static final String NAME    = "ML PVP";
    public static final String VERSION = "1.0.0";

    private final Minecraft mc = Minecraft.func_71410_x();
    private PrintWriter out;
    private BufferedReader in;
    private boolean isConnecting = false;

    // Python backend port. Both self-play clients run this same jar, so the SECOND
    // client must override this to 9998 with a JVM arg: -Dmlpvp.port=9998 (the learner
    // stays on the default 9999). Single-client use (BC bot / recording) needs nothing.
    private final int aiPort = Integer.getInteger("mlpvp.port", 9999);

    // 1. Create the Keybindings and State Trackers
    private KeyBinding aiToggleKey;     // P - AI takes over the controls
    private KeyBinding recordToggleKey; // O - stream "recording=true" so the logger saves frames
    private boolean isAiActive = false;
    private boolean isRecording = false;
    private long tickCounter = 0; // lets Python detect session gaps when stacking frames

    // Model now predicts true per-tick deltas (label off-by-one fixed in training),
    // so no artificial boost is needed
    private float aiAimSensitivity = 1.0f;

    // Camera smoothing. We apply the whole per-tick rotation at tick START (physics
    // reads the final angle, so hit registration is unchanged). But the entity's
    // onUpdate() copies prevRotation = rotation during the tick, which zeroes the
    // camera's frame-to-frame interpolation and makes AI aim look 20 fps / steppy. At
    // tick END we restore prevRotation to the PRE-delta angle so the vanilla camera
    // sweeps prev->current smoothly across every render frame at the real framerate.
    private float preYaw, prePitch;
    private boolean rotationSmoothPending = false;

    // The "Mailbox" - Volatile ensures thread safety when reading/writing
    private volatile BotAction currentAction = new BotAction();
    // A chat command the AI wants run (e.g. "/tp" to reset a self-play round).
    // Must be executed on the client thread, so onClientTick drains it.
    private volatile String pendingCommand = null;

    // Control-loop staleness. Python echoes back (ack_tick) the tick of the state
    // each action was computed from. Healthy pipelining is staleness 1 at apply time:
    // this tick we apply the reply to LAST tick's state. When the two clients' tick
    // clocks sit nearly a full cycle apart, Python (which replies only after hearing
    // from BOTH fighters) answers one client just AFTER its next tick starts - that
    // client then applies every action a tick late (staleness 2). Double control
    // latency at the same AIM_GAIN is what reads as the crosshair orbiting/"spinning",
    // and because both tick clocks are periodic the bad phase persists all session
    // (any pause, e.g. opening a GUI, re-rolls it - which is why toggling video
    // settings "fixed" it). Fix: when the reply to last tick's state hasn't arrived
    // yet, wait up to FRESH_WAIT_MS for it instead of applying the stale action.
    // Costs 0 in a good phase, a few ms/tick in a bad one. Skipped when Python is
    // genuinely paused (lag > 4 ticks, e.g. a PPO update) or never acks (BC server).
    private static final int FRESH_WAIT_MS = 25;
    private long lastStaleness = -1;                       // reported in telemetry
    private long staleSum = 0, staleMax = 0, staleTicks = 0, staleWaitedMs = 0;

    // Data container for our inputs
    public static class BotAction {
        public boolean w, a, s, d, sprint, jump;
        public float yaw_delta, pitch_delta;
        public boolean left_click, right_click;
        public long ack_tick = -1;   // tick of the state this action responds to
    }

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        MinecraftForge.EVENT_BUS.register(this);

        // Register the keys in the Minecraft Controls menu
        aiToggleKey = new KeyBinding("Toggle AI", Keyboard.KEY_P, "ML PvP Bot");
        ClientRegistry.registerKeyBinding(aiToggleKey);
        recordToggleKey = new KeyBinding("Toggle Recording", Keyboard.KEY_O, "ML PvP Bot");
        ClientRegistry.registerKeyBinding(recordToggleKey);

        attemptBackgroundConnection();
    }

    private void attemptBackgroundConnection() {
        if (isConnecting || out != null) return;
        isConnecting = true;

        new Thread(() -> {
            try {
                Socket socket = new Socket("127.0.0.1", aiPort);
                out = new PrintWriter(socket.getOutputStream(), true);
                in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                System.out.println("[Telemetry] Connected to Python AI Server on port " + aiPort + "!");

                // Start a nested infinite loop just for reading commands from the AI
                String line;
                while ((line = in.readLine()) != null) {
                    JsonObject json = new JsonParser().parse(line).getAsJsonObject();

                    BotAction newAction = new BotAction();
                    newAction.w = json.has("w") && json.get("w").getAsBoolean();
                    newAction.a = json.has("a") && json.get("a").getAsBoolean();
                    newAction.s = json.has("s") && json.get("s").getAsBoolean();
                    newAction.d = json.has("d") && json.get("d").getAsBoolean();
                    newAction.sprint = json.has("sprint") && json.get("sprint").getAsBoolean();

                    newAction.yaw_delta = json.has("yaw_delta") ? json.get("yaw_delta").getAsFloat() : 0f;
                    newAction.pitch_delta = json.has("pitch_delta") ? json.get("pitch_delta").getAsFloat() : 0f;

                    newAction.ack_tick = json.has("ack_tick") ? json.get("ack_tick").getAsLong() : -1;

                    newAction.jump = json.has("jump") && json.get("jump").getAsBoolean();
                    newAction.left_click = json.has("left_click") && json.get("left_click").getAsBoolean();
                    newAction.right_click = json.has("right_click") && json.get("right_click").getAsBoolean();

                    // Out-of-band reset command (teleport/heal/regear between rounds)
                    if (json.has("command")) {
                        pendingCommand = json.get("command").getAsString();
                    }

                    // Put the new command in the mailbox
                    currentAction = newAction;
                }
            } catch (Exception e) {
                System.err.println("[Telemetry] Connection lost. Retrying...");
                out = null;
                in = null;
                isConnecting = false;
                try { Thread.sleep(5000); } catch (InterruptedException ignored) {}
                attemptBackgroundConnection();
            }
        }).start();
    }

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        // END phase: the player's onUpdate() has already run this tick and copied
        // prevRotation = rotation. Restore prev to the pre-delta angle so the camera
        // interpolates the sweep across the render frames instead of snapping.
        if (event.phase == TickEvent.Phase.END) {
            if (rotationSmoothPending && mc.field_71439_g != null) {
                mc.field_71439_g.field_70126_B = preYaw;
                mc.field_71439_g.field_70127_C = prePitch;
                rotationSmoothPending = false;
            }
            return;
        }
        if (event.phase != TickEvent.Phase.START || mc.field_71439_g == null || mc.field_71441_e == null) return;

        // 2. The Toggle Logic
        if (recordToggleKey.func_151468_f()) {
            isRecording = !isRecording;
            String recMsg = isRecording ? "\u00A7e[ML Bot] RECORDING" : "\u00A77[ML Bot] RECORDING STOPPED";
            mc.field_71439_g.func_145747_a(new ChatComponentText(recMsg));
        }

        if (aiToggleKey.func_151468_f()) {
            isAiActive = !isAiActive;
            String statusMsg = isAiActive ? "\u00A7a[ML Bot] AI ACTIVATED" : "\u00A7c[ML Bot] AI DEACTIVATED";
            mc.field_71439_g.func_145747_a(new ChatComponentText(statusMsg));

            // Release all keys if we turn the AI off mid-fight to prevent ghost walking
            if (!isAiActive) {
                KeyBinding.func_74510_a(mc.field_71474_y.field_74351_w.func_151463_i(), false);
                KeyBinding.func_74510_a(mc.field_71474_y.field_74370_x.func_151463_i(), false);
                KeyBinding.func_74510_a(mc.field_71474_y.field_74368_y.func_151463_i(), false);
                KeyBinding.func_74510_a(mc.field_71474_y.field_74366_z.func_151463_i(), false);
                KeyBinding.func_74510_a(mc.field_71474_y.field_151444_V.func_151463_i(), false);
                KeyBinding.func_74510_a(mc.field_71474_y.field_74314_A.func_151463_i(), false);
                KeyBinding.func_74510_a(mc.field_71474_y.field_74313_G.func_151463_i(), false);
                rotationSmoothPending = false;  // hand the camera back to vanilla cleanly
            }
        }

        if (out == null) return;

        // Telemetry must flow EVERY tick, GUI or not - Python blocks on recv, so a
        // menu pausing telemetry on this client stalls the whole trainer. Note this
        // stream is NOT lockstep: states go out every tick whether or not Python has
        // replied, so Python drains to the freshest frame (see pvp_env._recv_state)
        // instead of consuming a stale backlog. A GUI only suppresses APPLYING
        // inputs (guiOpen below), never sending.
        boolean deathScreen = mc.field_71462_r instanceof GuiGameOver;
        boolean guiOpen = mc.field_71462_r != null && !deathScreen;
        // Nobody is around to click Respawn during self-play; click it ourselves.
        if (deathScreen && isAiActive && mc.field_71439_g.func_110143_aJ() <= 0.0F) {
            mc.field_71439_g.func_71004_bE();
        }

        // Run any queued reset commands on the client thread (Minecraft isn't
        // thread-safe). Python joins them with ";" - split back into one chat
        // message each, or the server parses the whole line as a single command.
        if (pendingCommand != null) {
            String cmd = pendingCommand;
            pendingCommand = null;
            for (String part : cmd.split(";")) {
                String c = part.trim();
                if (!c.isEmpty()) mc.field_71439_g.func_71165_d(c);
            }
        }

        EntityPlayer target = null;
        double closestDist = Double.MAX_VALUE;

        // 3. Scan for closest Human Player (to send telemetry to AI)
        for (EntityPlayer player : mc.field_71441_e.field_73010_i) {
            if (player != mc.field_71439_g && !player.func_82150_aj()) {
                double dist = mc.field_71439_g.func_70032_d(player);
                if (dist < closestDist) {
                    closestDist = dist;
                    target = player;
                }
            }
        }

        // 4. Send the State to Python
        final long thisTick = tickCounter++;
        try {
            JsonObject json = new JsonObject();

            // Session bookkeeping - lets Python detect gaps when stacking frames
            json.addProperty("tick", thisTick);
            json.addProperty("recording", isRecording);
            // Last measured control-loop lag (ticks); healthy 1, phase-locked 2,
            // -1 until Python starts echoing ack_tick. Lets the trainer log it.
            json.addProperty("staleness", lastStaleness);

            // Game State
            json.addProperty("player_x", mc.field_71439_g.field_70165_t);
            json.addProperty("player_y", mc.field_71439_g.field_70163_u);
            json.addProperty("player_z", mc.field_71439_g.field_70161_v);
            json.addProperty("player_yaw", mc.field_71439_g.field_70177_z);
            json.addProperty("player_pitch", mc.field_71439_g.field_70125_A);
            json.addProperty("on_ground", mc.field_71439_g.field_70122_E);
            json.addProperty("my_vx", mc.field_71439_g.field_70165_t - mc.field_71439_g.field_70169_q);
            json.addProperty("my_vz", mc.field_71439_g.field_70161_v - mc.field_71439_g.field_70166_s);
            json.addProperty("my_vy", mc.field_71439_g.field_70163_u - mc.field_71439_g.field_70167_r);
            json.addProperty("my_hurt", mc.field_71439_g.field_70737_aN);
            json.addProperty("my_health", mc.field_71439_g.func_110143_aJ());

            if (target != null) {
                json.addProperty("target_x", target.field_70165_t);
                json.addProperty("target_y", target.field_70163_u);
                json.addProperty("target_z", target.field_70161_v);
                json.addProperty("target_dist", closestDist);
                json.addProperty("tgt_vx", target.field_70165_t - target.field_70169_q);
                json.addProperty("tgt_vy", target.field_70163_u - target.field_70167_r);
                json.addProperty("tgt_vz", target.field_70161_v - target.field_70166_s);
                json.addProperty("tgt_hurt", target.field_70737_aN);
                json.addProperty("tgt_health", target.func_110143_aJ());
            } else {
                json.addProperty("target_dist", -1.0);
            }

            // Human inputs - what the logger records as training labels
            json.addProperty("in_w", mc.field_71474_y.field_74351_w.func_151470_d());
            json.addProperty("in_a", mc.field_71474_y.field_74370_x.func_151470_d());
            json.addProperty("in_s", mc.field_71474_y.field_74368_y.func_151470_d());
            json.addProperty("in_d", mc.field_71474_y.field_74366_z.func_151470_d());
            // actual sprint state, not the keybind - double-tap-W sprinting never
            // presses keyBindSprint, so reading the key logs sprint as always-off
            json.addProperty("in_sprint", mc.field_71439_g.func_70051_ag());
            json.addProperty("in_jump", mc.field_71474_y.field_74314_A.func_151470_d());
            json.addProperty("in_left_click", mc.field_71474_y.field_74312_F.func_151470_d());
            json.addProperty("in_right_click", mc.field_71474_y.field_74313_G.func_151470_d());

            out.println(json.toString());
        } catch (Exception e) {
            out = null;
        }

        // --- APPLY AI ACTIONS ---
        // Skipped while a menu is open (telemetry above still ran, keeping lockstep);
        // release the movement keys so the bot doesn't ghost-walk under the GUI.
        if (isAiActive && guiOpen) {
            KeyBinding.func_74510_a(mc.field_71474_y.field_74351_w.func_151463_i(), false);
            KeyBinding.func_74510_a(mc.field_71474_y.field_74370_x.func_151463_i(), false);
            KeyBinding.func_74510_a(mc.field_71474_y.field_74368_y.func_151463_i(), false);
            KeyBinding.func_74510_a(mc.field_71474_y.field_74366_z.func_151463_i(), false);
            KeyBinding.func_74510_a(mc.field_71474_y.field_74314_A.func_151463_i(), false);
            KeyBinding.func_74510_a(mc.field_71474_y.field_74313_G.func_151463_i(), false);
        }
        if (isAiActive && !guiOpen) {
            // Anti-phase-lock: the action we SHOULD apply this tick is the reply to
            // last tick's state (ack == thisTick-1). If it hasn't arrived yet - the
            // reply is in flight because the other client's tick clock sits just
            // before ours - wait briefly for it rather than applying a stale action.
            // lag > 4 means Python is paused (PPO update / reset), not phase-lagged;
            // ack < 0 means Python isn't echoing (old server) - don't wait for those.
            long lag = (thisTick - 1) - currentAction.ack_tick;
            if (currentAction.ack_tick >= 0 && lag >= 1 && lag <= 4) {
                int waited = 0;
                while (waited < FRESH_WAIT_MS
                        && (thisTick - 1) - currentAction.ack_tick >= 1) {
                    try { Thread.sleep(1); } catch (InterruptedException e) { break; }
                    waited++;
                }
                staleWaitedMs += waited;
            }
            BotAction action = currentAction;

            // Staleness bookkeeping: summary line every 200 ticks (~10 s).
            if (action.ack_tick >= 0) {
                lastStaleness = thisTick - action.ack_tick;
                staleSum += lastStaleness;
                staleMax = Math.max(staleMax, lastStaleness);
                staleTicks++;
                if (staleTicks >= 200) {
                    System.out.println(String.format(
                        "[mlpvp:%d] staleness avg %.2f max %d over %d ticks (waited %d ms)",
                        aiPort, staleSum / (double) staleTicks, staleMax, staleTicks,
                        staleWaitedMs));
                    staleSum = staleMax = staleTicks = staleWaitedMs = 0;
                }
            }

            KeyBinding.func_74510_a(mc.field_71474_y.field_74351_w.func_151463_i(), action.w);
            KeyBinding.func_74510_a(mc.field_71474_y.field_74370_x.func_151463_i(), action.a);
            KeyBinding.func_74510_a(mc.field_71474_y.field_74368_y.func_151463_i(), action.s);
            KeyBinding.func_74510_a(mc.field_71474_y.field_74366_z.func_151463_i(), action.d);
            KeyBinding.func_74510_a(mc.field_71474_y.field_74314_A.func_151463_i(), action.jump);

            // Sprint: drive the entity flag directly, not the keybind. A toggle-sprint
            // setup never holds keyBindSprint, so writing that key's state does nothing
            // (or fights the toggle). setSprinting is what actually gates the 1.3x speed
            // and the sprint knockback we W-tap to reset.
            KeyBinding.func_74510_a(mc.field_71474_y.field_151444_V.func_151463_i(), action.sprint);
            mc.field_71439_g.func_70031_b(action.sprint && action.w);

            // Remember the pre-delta angle so onClientTick END can restore prevRotation
            // and the camera interpolates this tick's rotation smoothly (see field docs).
            preYaw = mc.field_71439_g.field_70177_z;
            prePitch = mc.field_71439_g.field_70125_A;
            mc.field_71439_g.field_70177_z += (action.yaw_delta * aiAimSensitivity);
            mc.field_71439_g.field_70125_A += (action.pitch_delta * aiAimSensitivity);
            // Vanilla mouse input can never push pitch past vertical; neither may the AI
            mc.field_71439_g.field_70125_A = Math.max(-90f, Math.min(90f, mc.field_71439_g.field_70125_A));
            rotationSmoothPending = true;

            // Attack is an edge - onTick queues exactly one clickMouse() next runTick.
            if (action.left_click) {
                KeyBinding.func_74507_a(mc.field_71474_y.field_74312_F.func_151463_i());
            }
            // Blocking is a HOLD. onTick fires a single press, which is why sword-block
            // never engaged; vanilla only blocks while keyBindUseItem.isKeyDown().
            KeyBinding.func_74510_a(mc.field_71474_y.field_74313_G.func_151463_i(), action.right_click);

            // Consume impulses so we don't get the helicopter neck bug
            action.yaw_delta = 0;
            action.pitch_delta = 0;
            action.left_click = false;
            action.jump = false;
        }
    }
}