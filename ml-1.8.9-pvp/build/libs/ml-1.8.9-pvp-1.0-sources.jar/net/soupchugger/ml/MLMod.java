package net.soupchugger.ml;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ChatComponentText;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

@Mod(
        modid   = MLMod.MODID,
        name    = MLMod.NAME,
        version = MLMod.VERSION,
        clientSideOnly = true
)
public class MLMod {

    public static final String MODID   = "mlpvp";
    public static final String NAME    = "ML PVP";
    public static final String VERSION = "1.0.0";

    private final Minecraft mc = Minecraft.func_71410_x();
    private PrintWriter out;
    private BufferedReader in;
    private boolean isConnecting = false;

    // 1. Create the Keybinding and State Tracker
    private KeyBinding recordKey;
    private boolean isAiActive = false;

    // --- NEW: AI Aim Sensitivity Multiplier ---
    // Boosts the AI's smoothed mouse movements to combat MSE regression lag
    private float aiAimSensitivity = 2.5f;

    // The "Mailbox" - Volatile ensures thread safety when reading/writing
    private volatile BotAction currentAction = new BotAction();

    // Data container for our inputs
    public static class BotAction {
        public boolean w, a, s, d, sprint;
        public float yaw_delta, pitch_delta;
        public boolean left_click, right_click;
    }

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        MinecraftForge.EVENT_BUS.register(this);

        // Register the 'P' key in the Minecraft Controls menu
        recordKey = new KeyBinding("Toggle AI", Keyboard.KEY_P, "ML PvP Bot");
        ClientRegistry.registerKeyBinding(recordKey);

        attemptBackgroundConnection();
    }

    private void attemptBackgroundConnection() {
        if (isConnecting || out != null) return;
        isConnecting = true;

        new Thread(() -> {
            try {
                Socket socket = new Socket("127.0.0.1", 9999);
                out = new PrintWriter(socket.getOutputStream(), true);
                in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                System.out.println("[Telemetry] Connected to Python AI Server!");

                // Start a nested infinite loop just for reading commands from the AI
                String line;
                while ((line = in.readLine()) != null) {
                    JsonObject json = new JsonParser().parse(line).getAsJsonObject();

                    BotAction newAction = new BotAction();
                    newAction.w = json.has("w") && json.get("w").getAsBoolean();
                    newAction.a = json.has("a") && json.get("a").getAsBoolean();
                    newAction.s = json.has("s") && json.get("s").getAsBoolean();
                    newAction.d = json.has("d") && json.get("d").getAsBoolean();
                    newAction.sprint = json.has("sprint") && json.get("sprint").getAsBoolean();

                    newAction.yaw_delta = json.has("yaw_delta") ? json.get("yaw_delta").getAsFloat() : 0f;
                    newAction.pitch_delta = json.has("pitch_delta") ? json.get("pitch_delta").getAsFloat() : 0f;

                    newAction.left_click = json.has("left_click") && json.get("left_click").getAsBoolean();
                    newAction.right_click = json.has("right_click") && json.get("right_click").getAsBoolean();

                    // Put the new command in the mailbox
                    currentAction = newAction;
                }
            } catch (Exception e) {
                System.err.println("[Telemetry] Connection lost. Retrying...");
                out = null;
                in = null;
                isConnecting = false;
                try { Thread.sleep(5000); } catch (InterruptedException ignored) {}
                attemptBackgroundConnection();
            }
        }).start();
    }

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.START || mc.field_71439_g == null || mc.field_71441_e == null) return;

        // 2. The Toggle Logic
        if (recordKey.func_151468_f()) {
            isAiActive = !isAiActive;
            String statusMsg = isAiActive ? "\u00A7a[ML Bot] AI ACTIVATED" : "\u00A7c[ML Bot] AI DEACTIVATED";
            mc.field_71439_g.func_145747_a(new ChatComponentText(statusMsg));

            // Release all keys if we turn the AI off mid-fight to prevent ghost walking
            if (!isAiActive) {
                KeyBinding.func_74510_a(mc.field_71474_y.field_74351_w.func_151463_i(), false);
                KeyBinding.func_74510_a(mc.field_71474_y.field_74370_x.func_151463_i(), false);
                KeyBinding.func_74510_a(mc.field_71474_y.field_74368_y.func_151463_i(), false);
                KeyBinding.func_74510_a(mc.field_71474_y.field_74366_z.func_151463_i(), false);
                KeyBinding.func_74510_a(mc.field_71474_y.field_151444_V.func_151463_i(), false);
            }
        }

        // If a GUI is open or socket is dead, freeze
        if (mc.field_71462_r != null || out == null) return;

        EntityPlayer target = null;
        double closestDist = Double.MAX_VALUE;

        // 3. Scan for closest Human Player (to send telemetry to AI)
        for (EntityPlayer player : mc.field_71441_e.field_73010_i) {
            if (player != mc.field_71439_g && !player.func_82150_aj()) {
                double dist = mc.field_71439_g.func_70032_d(player);
                if (dist < closestDist) {
                    closestDist = dist;
                    target = player;
                }
            }
        }

        // 4. Send the State to Python
        try {
            JsonObject json = new JsonObject();

            // Game State
            json.addProperty("player_x", mc.field_71439_g.field_70165_t);
            json.addProperty("player_y", mc.field_71439_g.field_70163_u);
            json.addProperty("player_z", mc.field_71439_g.field_70161_v);
            json.addProperty("player_yaw", mc.field_71439_g.field_70177_z);
            json.addProperty("player_pitch", mc.field_71439_g.field_70125_A);
            json.addProperty("on_ground", mc.field_71439_g.field_70122_E);

            if (target != null) {
                json.addProperty("target_x", target.field_70165_t);
                json.addProperty("target_y", target.field_70163_u);
                json.addProperty("target_z", target.field_70161_v);
                json.addProperty("target_dist", closestDist);
            } else {
                json.addProperty("target_dist", -1.0);
            }

            out.println(json.toString());
        } catch (Exception e) {
            out = null;
        }

        // --- APPLY AI ACTIONS ---
        if (isAiActive) {
            BotAction action = currentAction;

            KeyBinding.func_74510_a(mc.field_71474_y.field_74351_w.func_151463_i(), action.w);
            KeyBinding.func_74510_a(mc.field_71474_y.field_74370_x.func_151463_i(), action.a);
            KeyBinding.func_74510_a(mc.field_71474_y.field_74368_y.func_151463_i(), action.s);
            KeyBinding.func_74510_a(mc.field_71474_y.field_74366_z.func_151463_i(), action.d);
            KeyBinding.func_74510_a(mc.field_71474_y.field_151444_V.func_151463_i(), action.sprint);

            // Apply the sensitivity multiplier to counteract PyTorch MSE smoothing
            mc.field_71439_g.field_70177_z += (action.yaw_delta * aiAimSensitivity);
            mc.field_71439_g.field_70125_A += (action.pitch_delta * aiAimSensitivity);

            if (action.left_click) {
                KeyBinding.func_74507_a(mc.field_71474_y.field_74312_F.func_151463_i());
            }
            if (action.right_click) {
                KeyBinding.func_74507_a(mc.field_71474_y.field_74313_G.func_151463_i());
            }

            // Consume impulses so we don't get the helicopter neck bug
            action.yaw_delta = 0;
            action.pitch_delta = 0;
            action.left_click = false;
            action.right_click = false;
        }
    }
}